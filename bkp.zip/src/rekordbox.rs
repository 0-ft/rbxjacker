use byteorder::*;
use process_list::for_each_module;
use read_process_memory::*;
use std::convert::TryInto;
use sysinfo::{PidExt, ProcessExt, SystemExt};

const TRACK_1_OFFSET: [u32; 6] = [0x03FB2B08, 0x0, 0x240, 0x78, 0x108, 0x148];
const TRACK_2_OFFSET: [u32; 4] = [0x03FB2B08, 0x8, 0x230, 0x148];

const TRACK_1_TITLE: [u32; 5] = [0x03FA6B10, 0x780, 0x170, 0x0, 0x0];
const TRACK_2_TITLE: [u32; 3] = [0x03F4D188, 0x318, 0x0];

const CROSSFADER: [u32; 6] = [0x03FA6B10, 0x200, 0x40, 0x30, 0xE0, 0xB4];

// // #[inline]
// fn vec_to_arr<T, const N: usize>(v: Vec<T>) -> [T; N] {
//     v.try_into()
//         .unwrap_or_else(|v: Vec<T>| panic!("Expected a Vec of length {} but it was {}", N, v.len()))
// }

// #[inline]
fn le_double(bytes: Vec<u8>) -> f64 {
    return byteorder::LittleEndian::read_f64(bytes.as_slice());
}

// #[inline]
fn le_float(bytes: Vec<u8>) -> f32 {
    return byteorder::LittleEndian::read_f32(bytes.as_slice());
}

fn modules_by_name(pid: sysinfo::Pid) -> Vec<(String, usize)> {
    let mut modules = Vec::new();
    for_each_module(pid.as_u32(), |(module_base, _size), name| {
        let name = name
            .file_name().unwrap()
            .to_str().unwrap()
            .trim_matches(char::from(0));
        modules.push((String::from(name), module_base));
    }).unwrap();
    return modules;
}

fn open_module(name: &str, module_name: &str) -> Option<(ProcessHandle, usize)> {
    let mut system = sysinfo::System::new_all();
    system.refresh_all();

    let mut processes = system.processes_by_exact_name(name);
    let proc = processes.next()?;

    let pid = proc.pid();
    println!("found process {:?}", pid);
    let modules = modules_by_name(pid);
    let module = modules
        .into_iter()
        .find(|m| m.0.eq(module_name))?;

    println!("found module at {:#x?}", module.1);
    let handle = pid.as_u32().try_into().ok()?;
    return Some((handle, module.1));
}

// fn open_module_2(name: &str, module_name: &str) -> Option<(ProcessHandle, usize)> {
//     let process = Process::from_name("rekordbox.exe").ok()?;
//     let module = process.module("rekordbox.exe").ok()?;
//     return (process.handle(), module.handle() as usize);
// }

pub struct RekordboxUpdate {
    pub track_1_title: Option<String>,
    pub track_2_title: Option<String>,
    pub track_1_offset: Option<f64>,
    pub track_2_offset: Option<f64>,
    pub crossfader: Option<f32>,
}

pub struct RekordboxAccess {
    handle: ProcessHandle,
    module_base: usize,
    track_1_title_address: CachedPointerChain,
    track_2_title_address: CachedPointerChain,
    track_1_offset_address: CachedPointerChain,
    track_2_offset_address: CachedPointerChain,
    crossfader_address: CachedPointerChain,
}

impl RekordboxAccess {
    pub fn attach() -> Option<RekordboxAccess> {
        let (handle, module_base) = open_module("rekordbox.exe", "rekordbox.exe")?;
        let rekordbox_access = RekordboxAccess {
            handle: handle,
            module_base: module_base,
            track_1_title_address: CachedPointerChain::make(TRACK_1_TITLE.to_vec()),
            track_2_title_address: CachedPointerChain::make(TRACK_2_TITLE.to_vec()),
            track_1_offset_address: CachedPointerChain::make(TRACK_1_OFFSET.to_vec()),
            track_2_offset_address: CachedPointerChain::make(TRACK_2_OFFSET.to_vec()),
            crossfader_address: CachedPointerChain::make(CROSSFADER.to_vec()),
        };
        return Some(rekordbox_access);
    }

    pub fn get_update(&mut self) -> RekordboxUpdate {
        let track_1_offset =
            self.track_1_offset_address
                .get_double(&self.handle, self.module_base, true);
        let track_2_offset =
            self.track_2_offset_address
                .get_double(&self.handle, self.module_base, true);

        let track_1_title =
            self.track_1_title_address
                .get_string(&self.handle, self.module_base, false);
        let track_2_title =
            self.track_2_title_address
                .get_string(&self.handle, self.module_base, false);

        let crossfader = self
            .crossfader_address
            .get_bytes(&self.handle, self.module_base, 4, true)
            .and_then(|bytes| Some((le_float(bytes) + 2.5625) / 5.125));

        return RekordboxUpdate {
            track_1_title,
            track_2_title,
            track_1_offset,
            track_2_offset,
            crossfader,
        };
    }
}

struct CachedPointerChain {
    chain: Vec<u32>,
    cached_addr: Option<usize>,
}

impl CachedPointerChain {
    fn make(chain: Vec<u32>) -> CachedPointerChain {
        return CachedPointerChain {
            chain: chain,
            cached_addr: None,
        };
    }

    fn follow_chain(&mut self, handle: &ProcessHandle, module_base: usize) -> Option<usize> {
        let mut pos: usize = module_base + self.chain[0] as usize;
        for offset in self.chain[1..].iter() {
            let bytes = copy_address(pos, 8, handle).ok()?;
            let pointer = byteorder::LittleEndian::read_i64(bytes.as_slice());
            pos = (pointer as usize) + (*offset as usize);
        }
        self.cached_addr = Some(pos);
        return Some(pos as usize);
    }
    fn get_bytes(
        &mut self,
        handle: &ProcessHandle,
        module_base: usize,
        num_bytes: usize,
        try_without_cache: bool,
    ) -> Option<Vec<u8>> {
        if try_without_cache && self.cached_addr.is_some() {
            let result = self
                .cached_addr
                .and_then(|addr| copy_address(addr, num_bytes, handle).ok());
            if result.is_some() {
                return result;
            }
        }
        self.follow_chain(handle, module_base);

        let result = self
            .cached_addr
            .and_then(|addr| copy_address(addr, num_bytes, handle).ok());
        return result;
    }

    fn get_string(
        &mut self,
        handle: &ProcessHandle,
        module_base: usize,
        try_without_cache: bool,
    ) -> Option<String> {
        let bytes = self.get_bytes(handle, module_base, 128, try_without_cache)?;
        let zero_index = bytes.iter().position(|x| *x == 0)?;
        return String::from_utf8(bytes[..zero_index].to_vec()).ok();
    }

    fn get_double(
        &mut self,
        handle: &ProcessHandle,
        module_base: usize,
        try_without_cache: bool,
    ) -> Option<f64> {
        return self
            .get_bytes(handle, module_base, 8, try_without_cache)
            .and_then(|bytes| Some(le_double(bytes)));
    }
}

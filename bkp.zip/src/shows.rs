use serde::{Deserialize, Serialize};
use std::collections::HashMap;
use std::fs::{read_to_string, File};
// mod rekordbox;

use crate::rekordbox::RekordboxUpdate;

const GRAPH_CHARS: [char; 9] = [' ', '▁', '▂', '▃', '▄', '▅', '▆', '▇', '█'];

#[derive(Serialize, Deserialize)]
struct ShowJson {
    title: String,
    path: String,
    frameRate: usize,
}

#[derive(Serialize, Deserialize)]
struct ShowsJson {
    shows: Vec<ShowJson>,
}

struct Show {
    // data: Vec<Vec<u8>>,
    frames: Vec<Vec<u8>>,
    length: i32,
    lights: usize,
    frame_rate: usize,
}

pub struct ShowsManager {
    shows: HashMap<String, Show>,
}

fn transpose<T>(v: &Vec<Vec<T>>) -> Vec<Vec<T>>
where
    T: Clone,
{
    assert!(!v.is_empty());
    (0..v[0].len())
        .map(|i| v.iter().map(|inner| inner[i].clone()).collect::<Vec<T>>())
        .collect()
}

impl ShowsManager {
    fn load_show_file(path: &str, frame_rate: usize) -> Option<Show> {
        println!("{}", path);
        let decoder = png::Decoder::new(File::open(path).ok()?);
        let (info, mut reader) = decoder.read_info().ok()?;
        let mut buf = vec![0; info.buffer_size()];
        reader.next_frame(&mut buf).ok()?;
        let rows: Vec<Vec<u8>> = buf
            .chunks(info.line_size)
            .map(|v| v.iter().map(|x| *x).step_by(4).collect())
            .collect();
        let frames: Vec<Vec<u8>> = transpose(&rows);
        
        let lights = rows.len();
        let length = rows[0].len() as i32;
        return Some(Show {
            // data: rows,
            frames: frames,
            length: length,
            lights: lights,
            frame_rate: frame_rate,
        });
    }

    fn get_show_frame(show: &Show, index: i32) -> Vec<u8> {
        if index < show.length && 0 <= index {
            return show.frames[index as usize].clone();
                // .data
                // .iter()
                // .map(|row| row[index as usize])
                // .collect();
            // return frame;
        }
        return vec![0; show.lights];
    }

    pub fn from_json(shows_json_path: &str) -> ShowsManager {
        let json_content: String = read_to_string(shows_json_path).expect("Could not read shows JSON");
        let json: ShowsJson =
            serde_json::from_str(json_content.as_str()).expect("JSON was not well-formatted");
        let shows: HashMap<String, Show> = json
            .shows
            .into_iter()
            .map(|s| {
                (
                    s.title,
                    ShowsManager::load_show_file(s.path.as_str(), s.frameRate),
                )
            })
            .filter(|(_title, show)| show.is_some())
            .map(|(title, show)| (title, show.unwrap()))
            .collect();
        println!("loaded {} shows", shows.len());
        return ShowsManager { shows: shows };
    }

    pub fn get_frame_for_title(&self, title: String, offset: f64) -> Option<Vec<u8>> {
        let show = self.shows.get(&title)?;
        let frame_index = (offset * show.frame_rate as f64).floor() as i32 % show.length;
        let frame = ShowsManager::get_show_frame(show, frame_index);
        return Some(frame);
    }

    pub fn combine_frames(
        track_1_frame: Option<Vec<u8>>,
        track_2_frame: Option<Vec<u8>>,
        crossfader: f32,
        lights: usize,
    ) -> Vec<u8> {
        let left_frame = track_1_frame.unwrap_or(vec![0; lights]);
        let right_frame = track_2_frame.unwrap_or(vec![0; lights]);
        let out_frame = left_frame
            .iter()
            .zip(right_frame)
            .map(|(a, b)| *a as f32 * crossfader + b as f32 * (1.0 - crossfader))
            .map(|sum| if sum > 255.0 { 255 } else { sum as u8 })
            .collect();
        return out_frame;
    }

    pub fn get_frame_from_rekordbox_update(&self, rekordbox_update: RekordboxUpdate) -> Vec<u8> {
        let track_1_frame = rekordbox_update.track_1_title.and_then(|title| {
            rekordbox_update
                .track_1_offset
                .and_then(|offset| self.get_frame_for_title(title, offset))
        });
        let track_2_frame = rekordbox_update.track_2_title.and_then(|title| {
            rekordbox_update
                .track_2_offset
                .and_then(|offset| self.get_frame_for_title(title, offset))
        });

        let out_frame = ShowsManager::combine_frames(
            track_1_frame,
            track_2_frame,
            rekordbox_update.crossfader.unwrap_or(0.5),
            16,
        );

        return out_frame;
    }
}

pub fn levels_to_graph(levels: &Vec<u8>) -> String {
    return levels
        .iter()
        .map(|l| GRAPH_CHARS[(*l / 32) as usize] as char)
        .collect();
}

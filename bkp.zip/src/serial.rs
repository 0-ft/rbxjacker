use serialport;
use std::time::Duration;

pub struct SerialLightOutput {
    port_name: String,
    port: Option<Box<dyn serialport::SerialPort>>
}

impl SerialLightOutput {
    pub fn connect(&mut self) -> bool {
        // let ports = serialport::available_ports().expect("No ports found!");
        // let port_name: String = ports[0].port_name.clone();
        // println!("opening port {}", self.port_name);
        self.port = serialport::new(self.port_name.as_str(), 921600)
            .timeout(Duration::from_millis(100))
            .open()
            .ok();
        let success = self.port.is_some();
        if success {
            println!("successfully opened {}", self.port_name);
        // } else {
        //     println!("failed to open {}", self.port_name);
        }
        return success;
    }

    pub fn make(serial_port: &String) -> SerialLightOutput {
        return SerialLightOutput {
            port: None,
            port_name: serial_port.clone(),
        };
    }

    pub fn is_connected(&self) -> bool {
        return self.port.is_some();
    }

    pub fn write_frame(&mut self, frame: &Vec<u8>) -> bool {
        if let Some(ref mut port) = self.port {
            let checksum: u8 = frame.iter().sum();
            let info = ['\n' as u8, frame.len() as u8, checksum];
            let msg = [&info[..], &frame[..]].concat();
            let success = port.write_all(msg.as_slice()).is_ok();
            if !success {
                self.port = None;
            }
            return success;
        } else {
            self.connect();
            return false;
        }
    }
}

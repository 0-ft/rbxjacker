use std::time;
mod shows;
use shows::{ShowsManager, levels_to_graph};
use std::env;

mod rekordbox;
use rekordbox::RekordboxAccess;

// mod preview;
// use preview::{show_preview};

mod serial;
use serial::SerialLightOutput;

// fn display_loop(mut rekordbox_access: RekordboxAccess, shows_manager: ShowsManager) {
//     // let delay = time::Duration::from_micros(2);
//     let mut i: i64 = 0;
//     // let empty_show = vec![vec![0; 1]; 16];
//     let mut start = time::Instant::now();
//     // loop {

//     //     let track_1_chars = levels_to_graph(out_frame);
//     //     i += 1;
//     //     if (i % 1000 == 0) {
//     //         println!("{}, {:?}", track_1_chars, start.elapsed());
//     //         start = time::Instant::now()
//     //     }
//     // }
// }

fn output_loop(mut rekordbox_access: RekordboxAccess, shows_manager: ShowsManager, mut serial_output: SerialLightOutput) {
    // let delay = time::Duration::from_micros(2);
    let mut i: i64 = 0;
    let mut start = time::Instant::now();
    loop {
        let rekordbox_update = rekordbox_access.get_update();
        let out_frame = shows_manager
            .get_frame_from_rekordbox_update(rekordbox_update);
        // if(out_frame != prevFrame) {
            let s = serial_output.write_frame(&out_frame);
            // prevFrame = out_frame.clone();
        // }
        i += 1;
        if i % 1000 == 0 {
            let frame_chars = levels_to_graph(&out_frame);
            println!("serial: {}, elapsed: {:?}, frame: {}", serial_output.is_connected(), start.elapsed(), frame_chars);
            start = time::Instant::now()
        }
    }
}

fn main() {
    let args: Vec<String> = env::args().collect();
    let shows_manager = ShowsManager::from_json("shows/shows.json");
    let rekordbox_access = RekordboxAccess::attach().expect("could not attach to rekordbox");
    let mut serial_output = SerialLightOutput::make(&args[1]);
    serial_output.connect();
    println!("finished setup");
    // show_preview();
    output_loop(rekordbox_access, shows_manager, serial_output)
}
